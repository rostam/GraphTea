Welcome to GraphTea!

What's new
-------------------------------------
March 22 2012
we are working on making the user interface more simple

March 7 2011
Graphs can now have loops!
- Add a loop by double clicking a vertex.
- Resize a loop or change its orientation in Curved Edges mode.
Modified classes are:
EdgeModel, FastRenderer, GraphControl, GraphModel and DragEdge. 
changes are also specified in revision log.
(Added by Mohsen Mansouryar <mansouryar@cs.sharif.edu>)

aug 23 2010
hi

nov 13 2008
MaxIndependentSet Report Added.
ChromaticNumber Report Added.
Simple Graph FileFormat Added.


Release Notes
---------------------------------------

This is a pre release version. 
Please help us by reporting bugs!

Requirement
---------------------------------------

In case you have just downloaded and unzipped your GraphTea distribution,
here's how to proceed:

First, you need Java2 (version 1.5 or higher) installed, get it from 
  http://java.sun.com 
for your platform.

In linux, you can run GraphTea with running the run.sh script.
It should be executable. So if it is not, make it executable by
running the command:
    chmod +x run.sh
You should have setted $JAVA_HOME if your java is not in path.
In windows, you can run GraphTea with just double clicking on
graphtea-main.jar file.

License
---------------------------------------

Files in graphtea.library package are distributed under the
terms of the Lesser GNU General Public License. Other files
are distributed under the terms of the GNU General Public License.

Thanks.